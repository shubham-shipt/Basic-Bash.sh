#!/bin/bash
echo "Delete a file:"
read file
rm -i "$file"
echo "File deleted"
