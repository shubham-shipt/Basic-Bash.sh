#!/bin/bash
echo "Change file permissions:"
read file
chmod +x "$file"
echo "Permissions changed"
