#!/bin/bash
echo "Show current working directory:"
pwd
