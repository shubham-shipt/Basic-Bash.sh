#!/bin/bash
echo "Check memory usage:"
free -h
