#!/bin/bash
echo "Uptime of the system:"
uptime
