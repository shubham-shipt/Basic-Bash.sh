#!/bin/bash
echo "Reverse a string:"
read str
echo "$str" | rev
