#!/bin/bash
echo "Display environment variables:"
printenv
