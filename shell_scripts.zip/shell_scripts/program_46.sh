#!/bin/bash
echo "Display file size:"
read file
du -h "$file"
