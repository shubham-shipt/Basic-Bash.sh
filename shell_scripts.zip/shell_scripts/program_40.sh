#!/bin/bash
echo "Sort numbers in a file:"
read file
sort -n "$file"
