#!/bin/bash
echo "Calculate power of a number:"
read base
read exp
echo "$((base ** exp))"
