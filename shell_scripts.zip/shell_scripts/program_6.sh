#!/bin/bash
echo "Disk usage:"
df -h
