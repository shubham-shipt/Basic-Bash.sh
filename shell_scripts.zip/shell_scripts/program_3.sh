#!/bin/bash
echo "Date: $(date)"
