#!/bin/bash
echo "Enter two numbers: "
read a
read b
echo "Sum: $((a + b))"
