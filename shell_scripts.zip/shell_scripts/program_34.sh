#!/bin/bash
echo "Read content of a file:"
read file
cat "$file"
