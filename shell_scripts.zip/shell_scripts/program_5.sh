#!/bin/bash
echo "File listing: "
ls
