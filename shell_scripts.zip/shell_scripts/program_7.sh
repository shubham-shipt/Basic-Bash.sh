#!/bin/bash
echo "Current logged-in users:"
who
