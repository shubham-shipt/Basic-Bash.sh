#!/bin/bash
echo "Check disk space:"
df -h
