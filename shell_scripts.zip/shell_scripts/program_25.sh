#!/bin/bash
echo "List all files in a directory:"
read dir
ls -la "$dir"
