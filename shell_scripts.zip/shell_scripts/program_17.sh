#!/bin/bash
echo "Show system architecture:"
uname -m
