#!/bin/bash
echo "Show file permissions:"
read file
ls -l "$file"
