#!/bin/bash
echo "Create a directory:"
read dir
mkdir -p "$dir"
echo "Directory created: $dir"
