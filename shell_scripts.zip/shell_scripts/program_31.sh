#!/bin/bash
echo "Check network interfaces:"
ifconfig
