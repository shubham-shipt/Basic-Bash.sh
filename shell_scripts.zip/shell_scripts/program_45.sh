#!/bin/bash
echo "Send a desktop notification:"
notify-send "Hello from Shell Script!"
